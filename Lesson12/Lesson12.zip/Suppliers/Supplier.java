package Suppliers;

public interface Supplier{

    public void run();       
    
}
