package Products;

public interface Product {
    
    public String getType();
}


