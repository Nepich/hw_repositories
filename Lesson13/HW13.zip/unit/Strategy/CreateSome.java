package unit.Strategy;

import unit.Unit;

public interface CreateSome {
    
    public void setAtributes(Unit unit);
}
