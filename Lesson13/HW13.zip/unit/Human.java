package unit;

public class Human extends Unit {

    public Human(String name, int hp, int atack, int wearableWeight) {
        super(name, hp, atack, wearableWeight);
    }
    
}
