package unit;


public class Dwarf extends Unit {

    public Dwarf(String name, int hp, int atack, int wearableWeight) {
        super(name, hp, atack, wearableWeight);
    }
    
}
