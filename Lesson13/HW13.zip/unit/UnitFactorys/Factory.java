package unit.UnitFactorys;

import unit.Unit;
@FunctionalInterface
public interface Factory {
    public Unit create();
}
