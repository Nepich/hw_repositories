package unit;

public class Giant extends Unit {

    public Giant(String name, int hp, int atack, int wearableWeight) {
        super(name, hp, atack, wearableWeight);
    }
    
}
