package unit.strategyToCreateUnit;

import unit.Unit;

public interface StrategyInteface {
    public Unit createUnit();
}
