package unit;

public class Orc extends Unit {

    public Orc(String name, int hp, int atack, int wearableWeight) {
        super(name, hp, atack, wearableWeight);
    }
    
}
