package unit;

public class FlyingCreature extends Unit{
    
    public FlyingCreature(String name, int hp, int atack, int wearableWeight) {
        super(name, hp, atack, wearableWeight);
    }

    public void fly (double[] from, double[] to){
//в дальнейшем прописать полет откуда - куда
    }
}
