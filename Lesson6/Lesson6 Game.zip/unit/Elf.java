package unit;

public class Elf extends Unit {

    public Elf(String name, int hp, int atack, int wearableWeight) {
        super(name, hp, atack, wearableWeight);
    }
    
}
