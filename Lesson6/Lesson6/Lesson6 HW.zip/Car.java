package Lesson6.Lesson6;

public class Car {

    protected int speed;
    protected String color;
    protected String model;

    public Car (int speed, String color, String model){
        this.speed = speed;
        this.color = color;
        this.model = model;
    }
}
