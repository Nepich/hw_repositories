package unit.UnitFactorys;

import unit.Unit;

public abstract class Factory {
    public static Unit create() {
        Unit unit = new Unit(null, 0, 0, 0) {
        };
        return unit;
    }
}
