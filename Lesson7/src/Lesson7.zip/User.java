public class User <T,M> {
    public T id;
    public M card_number;
}
