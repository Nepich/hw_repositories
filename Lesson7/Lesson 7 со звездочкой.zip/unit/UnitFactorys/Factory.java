package unit.UnitFactorys;

import unit.Unit;

public interface Factory {
    public Unit create()/*{
    String name;
    int hp;
    int attack;
    int wearableWeight;
    Unit unit = new Unit(name,hp,attack,wearableWeight); 
    return unit;
    }*/;
}
