@FunctionalInterface
public interface Solver {
    int solve(int x, int y);
}
